
function submitPurchaseForm(event) {
    event.preventDefault();
    const name = document.getElementById('name').value;
    window.location.href = `purchase_confirmation.html?name=${encodeURIComponent(name)}`;
}

document.addEventListener('DOMContentLoaded', function () {
    const params = new URLSearchParams(window.location.search);
    const name = params.get('name');
    document.getElementById('customer-name').textContent = name;
});

function submitReviewForm(event) {
    event.preventDefault();
    const reviewText = document.getElementById('review').value;
    if (reviewText.trim() !== "") {
        const reviewList = document.querySelector('.reviews');
        const newReview = document.createElement('li');
        newReview.textContent = reviewText;
        reviewList.appendChild(newReview);
        document.getElementById('review').value = "";
    }
}

document.querySelector('.review-form').addEventListener('submit', submitReviewForm);